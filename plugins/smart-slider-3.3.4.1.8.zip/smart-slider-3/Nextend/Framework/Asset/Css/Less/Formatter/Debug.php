<?php


namespace Nextend\Framework\Asset\Css\Less\Formatter;


class Debug extends Classic {

    public $disableSingle = true;
    public $breakSelectors = true;
    public $assignSeparator = ": ";
    public $selectorSeparator = ",";
}