<?php

namespace Nextend\SmartSlider3\Generator\Common;

use Nextend\SmartSlider3\Generator\AbstractGeneratorLoader;

class GeneratorCommonLoader extends AbstractGeneratorLoader {

}